import gzip
import os 
import threading
import multiprocessing
import logging
import argparse
from tqdm import tqdm
from CUSTOM_EXCEPTION import( # Custom classes used for custom exceptions
    FileNotFoundCustomError,
    ChunkingFilesErrors,
    FileWriteError,
    GeneralCompressionError,
    InputOutputError
) 
import time
from cryptography.fernet import Fernet 

# Encryption Code 

key = Fernet.generate_key()

f = Fernet(key)

# Directories 
current_dir = os.getcwd()
comp_dir = "/workspaces/Saved_projects_exe/compressed_files"



logger = logging.getLogger("compression_tool")
logger.setLevel(logging.INFO)


console_handler = logging.StreamHandler()
console_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))

file_handler = logging.FileHandler("compression_tool.log")
file_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))

logger.addHandler(console_handler)
logger.addHandler(file_handler)

def get_size_in_bytes(file_path):
    """Obtaining size of the file 

    Parameters: 
    file_path: Path to the file

    Returns:
    int: File size in bytes

    Exceptions:
    FileNotFoundError : Raised when file_path is not located.
    """      
    try:
        file_size = os.path.getsize(file_path)  # Using OS module to get size of the file.
        logger.info(f"The file size of {file_path} is {file_size} bytes.")
        return file_size
    except FileNotFoundError:
        raise FileNotFoundCustomError(file_path)
       

def file_compression(file_path, output_dir, compression_level):
    """Compress the specified file and save it with a .gz extension
    
    Parameters:
    file_path = Path to the file
    output_dir = Stores compressed file in an output directory
    compression_level = Specifies the compression level ranging from 1 - 9:
    1: Fastest compression with least compression
    9: Slowest compression with higher compression ratio.

    Returns:
    Stores a compressed version of the file, in an output directory specified by user.

    Exception:
    OS Error: Raised when an OS error occurs.
    MemoryError: Raised when a Memory error occurs.
    Exception: Raised, if any other unexpected exception occurs.
    """
    try:
        # Ensure the file exists before attempting to open it
        if not os.path.exists(file_path):
            logger.info("File does not exist")
            raise FileNotFoundCustomError(file_path)

        with open(file_path, 'rb') as file:
            
            data = file.read()
            logger.info("Reads data from file") 

        compressed_data = gzip.compress(data, compresslevel=compression_level)  # Compresses data
        compressed_file_path = os.path.join(output_dir, f"{os.path.basename(file_path)}.gz")  # Separate file for compressed data

        with open(compressed_file_path, "wb") as compressed_file:
            logger.info("Writing data to compressed file")
            compressed_file.write(compressed_data)
            
        
        logger.info(f"Compressed file created at: {compressed_file_path}")

        return compressed_data
    
        

    except OSError as e:
        logging.exception("OS Error occured: {e}")
        raise FileWriteError(compressed_file_path)
    
    except MemoryError:
        raise GeneralCompressionError("Memory Error occurred during compression")
    
    except PermissionError as e:
        raise FileWriteError(f"Error while wrting in file: {e}")
    
    except Exception as e:
        logging.exception(f"An error occurred during compression: {e}")
        raise GeneralCompressionError(f"Compression Error occurance: {e}")

def write_data_to_chunks(file_path, chunk_size=1024*1024, output_dir="."):
    """Writes data to chunks for persistence
    
    Parameters:
    file_path: Path to the file
    chunk_size: Set to default (1024*1024), obtaining chunk size
    output directory: Data written to chunks, at specified directory "." can be modified by user.
    
    Returns:
    Writes data in chunks to an output directory
    
    Exceptions:
    OS Error: Raised when an OS error occurs.
    FileNotFoundError: Raised when file_path is not located.
    All Exceptions: Raised, if any other unexpected exception occurs
    
    """

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        logger.info(f"Output directory created successfully: {output_dir}")
    try: 
        with open(file_path, "rb") as main_file:
            chunk_index = 0
            while True:
                chunk = main_file.read(chunk_size)
                if not chunk:
                    logger.info("Execution of chunks, stopped.")
                    break

                chunk_file_path = os.path.join(output_dir, f"chunk_{chunk_index}.bin")
                with open(chunk_file_path, "wb") as chunk_file:
                    chunk_file.write(chunk)
                logger.info(f"Chunk {chunk_index} created at {chunk_file_path}.")
                chunk_index += 1
                logger.info(f"Chunk {chunk_index} created successfully at {chunk_file_path}")

    except FileNotFoundError:
        raise FileNotFoundCustomError(file_path)
    except OSError as e:
        logging.exception(f"OS Error occurred : {e}")
        raise ChunkingFilesErrors(f"OS Error during chunking: {e}")
    except IOError as e:
        raise ChunkingFilesErrors(f"Error while chunking files: {e} ")
    except Exception as e:
       raise GeneralCompressionError(str(e))

def read_and_chunk_files(file_path, chunk_index, chunk_size=1024*1024):
    """
    Reading and creating chunks

    Parameters: 
    file_path = Path to file
    chunk_index = Maintains metadata for file chunks including their byte ranges and checksums.
    chunk_size = Specifies the size of each chunk for file processing and compression. Defualt (1024 * 1024)

    Returns:
    Reads a part of a file based on the specified chunk index and  writes that part to a new chunk file.

    Exceptions:
    All Exceptions: Any occurance of an error is reported, with a friendly messsage.

    """
    try:
        with open(file_path, "rb") as main_file:
            main_file.seek(chunk_index * chunk_size) 
            chunk_data = main_file.read(chunk_size)

            if chunk_data: 
                chunk_file_path = os.path.join('.', f'chunk_{chunk_index}.bin')
                with open(chunk_file_path, 'wb') as chunk_file:
                    chunk_file.write(chunk_data)
                    logger.info("Chunk data written in chunk files, (later be used for multithreading and multiprocessing)")

                logger.info(f"Chunk {chunk_index} created with size {len(chunk_data)} bytes.")
            else:
                logger.info("No data available for the specified chunks.")
    except IOError:
        logging.exception("Error in IO opertions.")
        raise InputOutputError
    
    except Exception as e:
        logging.exception(f"Error occurance: {e}")
        raise GeneralCompressionError(str(e))
    
def download_progress_bar(num_chunks):
    """
    Display a 'downloading' style progress bar, simulating a countdown or step-based progress.
    """
    with tqdm(total=num_chunks, desc="Downloading", unit="chunk") as pbar:
        for i in range(1, num_chunks + 1):
            # This will simulate some delay, representing work being done (e.g., file chunking)
            time.sleep(0.1)  # You can adjust the speed here.
            pbar.set_postfix({"Current Chunk": i})  # Adding dynamic information on the progress bar
            pbar.update(1)
            



def chunking_large_files(file_path, chunk_size=1024*1024):
    """
    Compresses the file, as per allocated chunk size
    
    Parameters:
    file_path = Path to the file
    chunk_size: Specified chunk size for file compresssion and multiprocessing. Default(1024*1024)
    
    Returns:
    Chunks Larger files, through multiprocessing
    
    Exceptions:
    All Exceptions: Any occurance of an error, returns a friendly message to the user.

    """
    try:
        file_size = os.path.getsize(file_path)  # Gets size of file 
        num_chunks = (file_size + chunk_size - 1) // chunk_size

        threads = []
        with tqdm(total=num_chunks, desc="Creating Chunks") as pbar:
            for i in range(num_chunks):  # Iterates, for multithreading
                thread = threading.Thread(target=read_and_chunk_files, args=(file_path, i, chunk_size)) 
                threads.append(thread)
                logging.info(f"Starting Thread for {i} for chunking")
                thread.start()
                pbar.update(1)
                time.sleep(0.1)
            

            for thread in threads:
                thread.join()  # Joins all threads.
                logger.info(f"Thread Execution completed for {i} chunk.")
                download_progress_bar(num_chunks)

            logger.info("All chunks created")
    except IOError as e:
        logging.exception(f"Error in IO operation errors: {e}")
        raise ChunkingFilesErrors("Error while chunking files")
    except Exception as e:
       raise GeneralCompressionError(str(e))

def parallel_compression(file_paths, output_dir, compression_level):
    """
    Compress files in parallel.
    
    Parameters:
    file_path: Path to the file
    output_dir: Output directory, where compressed file will be stored
    compression_level: compression_level = Specifies the compression level ranging from 1 - 9:
    1: Fastest compression with least compression
    9: Slowest compression with higher compression ratio.
    
    Returns:
    A compressed version of a file in .gz stored in an output directory
    
    Exception:
    All Exception: Returns occurance of an error, but in a friendly message wihtout traFile Format Support:

Expand support to include other file formats, such as .zip and .tar.gz.ceback repports.

"""
    try:
        processes = []
        for file_path in tqdm(file_paths, desc="Processing"): # Creates progress bars using tqdm, for monitoring file paths processing.
            logging.info("Multiprocessing file paths started")
            if not os.path.exists(file_path): # Check if file path exists
                raise FileNotFoundCustomError(f"File not found: {file_path}")
                 
            # Multiprocessing used for parallel compression.
            process = multiprocessing.Process(target=file_compression, args=(file_path, output_dir, compression_level))
            processes.append(process) 
            logger.info("Multiprocessing started")
            process.start()

            num_chunks = len(file_paths)
           

        for process in tqdm(processes):
            logger.info("All processes joined for multi processing")
            download_progress_bar(num_chunks)
            process.join()
            logger.info("Multiprocessing successfull")

        logger.info("All files compressed")

    except multiprocessing.ProcessError as f:
        logger.exception("Error while parallel compression")
        raise GeneralCompressionError(f"Error while compressing {f}")
    
    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        raise FileWriteError("Error while files in parallel.")


def encryption_algorithm(input_file, output_dir, key_path):
    """Encrypt files in the input directory using an existing key."""
    try:
        # Load encryption key from the specified key file
        if not os.path.exists(key_path):
            logging.error(f"Encryption key file not found at {key_path}")
            raise FileNotFoundError(f"Encryption key file not found at {key_path}")
        
        with open(key_path, "rb") as key_file:
            key = key_file.read()
        f = Fernet(key)

        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            logging.info(f"Output directory {output_dir} created.")
        
     
        file_name = os.path.basename(input_file)
        file_name_without_extension, file_extension = os.path.splitext(file_name) 

        try:
            with open(input_file, "rb") as main_file:
                content = main_file.read()  

            encrypted_content = f.encrypt(content)  

            
            encrypted_file_name = file_name_without_extension + file_extension + ".enc"
            encrypted_file_path = os.path.join(output_dir, encrypted_file_name)
            
            with open(encrypted_file_path, "wb") as enc_file:
                enc_file.write(encrypted_content)  

            logging.info(f"Encrypted {file_name} and saved as {encrypted_file_path}")

        except Exception as e:
            logging.error(f"Error encrypting {file_name}: {e}")

    except Exception as e:
        logging.error(f"Error in encryption process: {e}")



def decryption_algorithm(input_file, output_dir, key_path):
    """Decrypt files in the input directory using an existing key."""
    try:
        # Validate input file existence
        encrypted_file_path = os.path.join("./encrypted_files", input_file)
        if not os.path.exists(encrypted_file_path):
            logging.error(f"Encrypted file not found: {encrypted_file_path}")
            raise FileNotFoundError(f"Encrypted file not found at {encrypted_file_path}")

        # Load encryption key
        if not os.path.exists(key_path):
            logging.error(f"Encryption key file not found at {key_path}")
            raise FileNotFoundError(f"Encryption key file not found at {key_path}")
        
        with open(key_path, "rb") as key_file:
            key = key_file.read()
        f = Fernet(key)

        # Create output directory if it doesn't exist
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            logging.info(f"Output directory {output_dir} created.")

        # Decrypt the file
        file_name = os.path.basename(input_file)
        
        try:
            with open(encrypted_file_path, "rb") as enc_file:
                encrypted_content = enc_file.read()
            
            decrypted_content = f.decrypt(encrypted_content)  # Decrypt file content
            
            # Restore the original file name and extension (remove ".enc" suffix)
            original_file_name = os.path.splitext(file_name)[0]  # Remove .enc extension
            decrypted_file_path = os.path.join(output_dir, original_file_name)

            with open(decrypted_file_path, "wb") as dec_file:
                dec_file.write(decrypted_content)
            
            logging.info(f"Decrypted file saved as {decrypted_file_path}")

        except Exception as e:
            logging.error(f"Error decrypting {file_name}: {e}")
            raise GeneralCompressionError(f"Decryption error: {e}")

    except Exception as e:
        logging.error(f"Error in decryption process: {e}")
        raise GeneralCompressionError(f"Decryption process failed: {e}")



      

def decompression_for_gz_files(input_file, output_dir):
    """Decompression for gz files

    Parameters:
     input_file: Input gz file for decompression.
     output_dir: Location at which the decompressed files is stored. 
     
    Returns:
    Returns a decompressed version of a file, in the specified output directory.
    """
    
    
    try:
        file_name, file_extension = os.path.splitext(input_file)
        if file_extension.endswith(".gz"):
            with gzip.open(input_file, "rb") as gz_file:
                decompressed_data = gz_file.read()  
                logger.info("Gz file data read for decompression")

            decompressed_file_path = os.path.join(output_dir, os.path.basename(file_name))
            logger.info("Decompressed file path created")

            with open(decompressed_file_path, "wb") as output_file:
                output_file.write(decompressed_data)
                logger.info(f"Decompressed file created at: {decompressed_file_path}")
        else:
            logger.warning("File extension is not .gz; skipping decompression.")
            raise InputOutputError("Unsupported filetype for decompression: {input_file}")
            

    except FileNotFoundError:
        raise FileNotFoundCustomError 
    
    except OSError as e:
        logging.exception(f"OS error occurance: {e}")

    except MemoryError as e :
        logging.exception(f"Memory error occurance: {e}")

    except Exception as e:
        # Occ
        logging.exception(f"Error during decompression: {e}")



def CLI():  # Command Line Interface
    """CLI (Command line interface, offering a user interface for compressing files.)"""

    logger.info("CLI Execution started")
    
    parser = argparse.ArgumentParser(description="File Compression Tool", usage="Compress files by specifying compression levels.")

    parser.add_argument("input_file",type=str, help="File to compress")
    parser.add_argument("--compression_level", default=9, help="Compression level (0-9)", type=int)
    parser.add_argument("--chunk_size", default=1024 * 1024, help="Define custom chunk size", type=int)
    parser.add_argument("--output_dir", default=".", help="Directory for the compressed file.")
    parser.add_argument("--logging_level" , help="Logging levels can either be (DEBUG, INFO, WARNING, ERROR, CRITICAL)")
    parser.add_argument("--gz_file", help="for decompressing gz files")
    parser.add_argument("--encrypt", action= "store_true", help="for encrypting files")
    parser.add_argument("--compress", help="For parallel compression of files")
    parser.add_argument("--key",type=str ,default="encryption_key.key",required=True,help="Path to the encryption key file")  # Added key argument
    parser.add_argument(
    "--decrypt",
    action="store_true",
    help="Enable decryption mode to decrypt a file from the encrypted_files directory."
)
    args = parser.parse_args()


    

    if not(0 <= args.compression_level <= 9):
        logger.error("Incorrect compression level")
        raise ValueError("Compression level should be between (0 - 9)")

    if args.logging_level:
        logging_level = getattr(logging, args.logging_level.upper(), logging.INFO)
        logger.setLevel(logging_level)
        logging.info(f"Logging level set to {args.logging_level.upper()}")
    else:
        logger.info("No logging level specified. Using default (INFO).")

 
    if not os.path.exists(args.output_dir):
        os.makedirs(args.output_dir)
        logger.info(f"Directory created at {args.output_dir}")

   

    if args.compress:

       parallel_compression([args.input_file], args.output_dir, args.compression_level)

    if args.gz_file:
        decompression_for_gz_files(args.input_file, args.output_dir)

    if args.encrypt:
        logger.info("Encryption mode activated.")
        
        if not os.path.exists(args.key):
            logger.error(f"Encryption key file not found at {args.key}")
            raise FileNotFoundError(f"Encryption key file not found at {args.key}")
        
        
        logger.info(f"Starting encryption for {args.input_file}...")
        encryption_algorithm(args.input_file, args.output_dir, args.key)

    if args.decrypt:
      logger.info("Decryption mode activated.")

  
      if not args.input_file.endswith(".enc"):
        logger.error("Decryption requires a file with a .enc extension.")
        raise ValueError("File must have a .enc extension for decryption.")
    
  
      encrypted_file_path = os.path.join("encrypted_files", args.input_file)
      if not os.path.exists(encrypted_file_path):
        logger.error(f"Encrypted file {args.input_file} does not exist in 'encrypted_files' directory.")
        raise FileNotFoundError(f"File {args.input_file} not found in 'encrypted_files'.")
    
   
      if not os.path.exists(args.key):
        logger.error(f"Encryption key file not found at {args.key}")
        raise FileNotFoundError(f"Encryption key file not found at {args.key}")
    
    # Attempt to decrypt the file
      logger.info(f"Decrypting file from {encrypted_file_path}...")
      try:
        decryption_algorithm(args.input_file, args.output_dir, args.key)
        logger.info(f"File {args.input_file} successfully decrypted and saved to {args.output_dir}.")
      except Exception as e:
        logger.error(f"Failed to decrypt the file: {e}")
        raise

        

    logger.info("CLI Execution Finished")

if __name__ == "__main__":
    CLI()


# For Encryption:
# python file_compression.py test.txt --encrypt --key encryption_key.key --output_dir ./encrypted_files

# For decryption
# python file_compression.py test.txt.enc --decrypt --key encryption_key.key --output_dir ./decrypted_files

# For Compression
# python file_compression.py test.txt --compression_level 7 --chunk_size 1048576 --output_dir ./compressed_files --compress

