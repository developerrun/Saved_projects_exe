import pygame
from pygame.sprite import Sprite

class Ship(Sprite):
    """Class to manage the ship."""
    
    def __init__(self, ai_game):
        """Initialize the ship and set its starting position."""
        super().__init__()
        self.screen = ai_game.screen  # Screen where the ship will be displayed
        self.screen_rect = ai_game.screen.get_rect()  # Rectangular area of the screen
        
        # Load the ship's image and get its rectangle
        self.image = pygame.image.load("images/ship.bmp")  # Load the ship image
        self.rect = self.image.get_rect()  # Get the rectangle of the ship image
        self.rect.midbottom = self.screen_rect.midbottom  # Position the ship at the bottom center of the screen
        
        # Flags to track movement
        self.moving_right = False  # Ship is not moving right initially
        self.moving_left = False   # Ship is not moving left initially
        
        # Access to settings for speed
        self.settings = ai_game.settings
        
        # Store a decimal value for the ship's horizontal position for smoother movement
        self.x = float(self.rect.x)

    def update(self):
        """Update the ship's position based on movement flags."""
        if self.moving_right and self.rect.right < self.screen_rect.right:
            self.x += self.settings.ship_speed  # Move the ship right, respecting the screen's right edge

        if self.moving_left and self.rect.left > 0:
            self.x -= self.settings.ship_speed  # Move the ship left, respecting the screen's left edge

        self.rect.x = self.x  # Apply the updated x position to the ship's rect

    def blitme(self):
        """Draw the ship at its current position."""
        self.screen.blit(self.image, self.rect)  # Blit (draw) the ship onto the screen at its rect position


    def center_ship(self):
        self.rect.midbottom = self.screen_rect.midbottom 
        self.x = float(self.rect.x)