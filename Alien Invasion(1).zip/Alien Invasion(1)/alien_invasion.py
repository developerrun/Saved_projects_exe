import sys
import pygame
from settings import Settings
from time import sleep 
from ship import Ship
from bullet import Bullet
from game_stats import GameStats
from button import Button 
from alien import Alien 
from scoreboard import Scoreboard

class AlienInvasion:
    """Overall class to manage game assets and behavior."""
    
    def __init__(self):
        """Initialize the game and create game resources."""
        pygame.init()  # Initialize pygame

        self.settings = Settings()  # Create an instance of the Settings class

        self.screen = pygame.display.set_mode((self.settings.screen_width, self.settings.screen_height))  # Set up the screen

        pygame.display.set_caption("Alien Invasion")  # Set the title of the game window

        self.clock = pygame.time.Clock()  # Create a clock object to control the frame rate

        self.ship = Ship(self)  # Create a ship object, passing the current game instance

        self.bullets = pygame.sprite.Group()  # Group to hold all active bullets

        self.aliens = pygame.sprite.Group() 

        self.stats = GameStats(self)

        self.game_active = True 

        self.game_active = False

        self.play_button = Button(self, "Play")

        self.score_board = Scoreboard(self) # Scoreboard instance

        

        self._create_fleet()

    def _check_aliens_bottom(self):
        for alien in self.aliens.sprites():
            if alien.rect.bottom >= self.settings.screen_height:
                self._ship_hit()
                break
    
    def _ship_hit(self):
        # Decrement ships left
        if self.stats.ships_left > 0:
            self.stats.ships_left -= 1
            self.score_board.prep_ships()

            # Get rid of any remaining bullets or ships 
            self.bullets.empty()
            self.aliens.empty()

            self._create_fleet()
            self.ship.center_ship()

            sleep(0.5)
        
        else:
            self.game_active = False 
            pygame.mouse.set_visible(True)
        
    
    def _change_fleet_direction(self):
        for aliens in self.aliens.sprites():
            aliens.rect.y += self.settings.fleet_drop_speed
            
        self.settings.fleet_direction *= -1 

    def _check_fleet_edges(self):
        for alien in self.aliens.sprites():
            if alien._check_edges():
                self._change_fleet_direction()
                break

    def _update_aliens(self):
        self._check_fleet_edges()
        self.aliens.update()

        # Look for alien-ship collision
        if pygame.sprite.spritecollideany(self.ship, self.aliens):
            self._ship_hit()

        self._check_aliens_bottom()

    def _create_fleet(self):
      """Create the fleet of aliens."""
      alien = Alien(self)
      alien_width, alien_height = alien.rect.size 

      current_x, current_y  = alien_width, alien_height 
      while current_y < (self.settings.screen_height - 4 * alien_height):
         while current_x < (self.settings.screen_width - 2 * alien_width):
            self._create_alien(current_x, current_y)
            current_x += 2 * alien_width

         current_x = alien_width 
         current_y += 2 * alien_height
             

    
    def _create_alien(self, x_position, y_position):
        new_alien = Alien(self)
        new_alien.x = x_position
        new_alien.rect.x = x_position
        new_alien.rect.y = y_position
        self.aliens.add(new_alien)

   

   
                
        
    
      
      
    def _check_event(self):
        """Check for keyboard and mouse events."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()  # Exit the game if the close button is clicked
            elif event.type == pygame.KEYDOWN:
                self._check_KEYDOWN_events(event)
            elif event.type == pygame.KEYUP:
                self._check_KEYUP_events(event)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                self._check_play_button(mouse_pos)

    def _check_play_button(self, mouse_pos):
       """Start a new game when the player clicks Play."""
       if self.play_button.rect.collidepoint(mouse_pos) and not self.game_active:
        # Reset the game statistics
        self.settings.initialize_dynamic_settings()
        self.score_board.prep_level()
        self.score_board.prep_ships()
        
        self.stats.reset_stats()


        self.game_active = True
        

        # Clear any remaining bullets and aliens
        self.bullets.empty()
        self.aliens.empty()

        # Create a new fleet and center the ship
        self._create_fleet()
        self.ship.center_ship()

        pygame.mouse.set_visible(False)

        # Reset game settings (if needed, like difficulty adjustments)
        




    def _check_KEYDOWN_events(self, event):
        """Respond to key presses."""
        if event.key == pygame.K_RIGHT:
            self.ship.moving_right = True  # Start moving the ship to the right
        elif event.key == pygame.K_LEFT:
            self.ship.moving_left = True  # Start moving the ship to the left
        elif event.key == pygame.K_q:
            sys.exit()  # Quit the game if 'q' is pressed
        elif event.key == pygame.K_SPACE:
            self._fire_bullet()  # Fire a bullet if spacebar is pressed

        elif event.key == pygame.K_p:
            self.game_active = True 

    def _check_KEYUP_events(self, event):
        """Respond to key releases."""
        if event.key == pygame.K_RIGHT:
            self.ship.moving_right = False  # Stop moving the ship to the right
        elif event.key == pygame.K_LEFT:
            self.ship.moving_left = False  # Stop moving the ship to the left

    def _fire_bullet(self):
        """Create a new bullet and add it to the bullets group."""
        if len(self.bullets) < self.settings.bullets_allowed:
            new_bullet = Bullet(self)
            self.bullets.add(new_bullet)  # Add the new bullet to the group

    


    def _update_bullets(self):
        """Update the position of bullets and remove off-screen bullets."""
        self.bullets.update()  # Update each bulles position
        # Remove bullets that are off the screen
        for bullet in self.bullets.copy():
            if bullet.rect.bottom <= 0:
                self.bullets.remove(bullet)
            
            if not self.aliens:
                self.bullets.empty()
                self._create_fleet()

        self._check_bullet_alien_collisions()
    
    def _check_bullet_alien_collisions(self):
        collisions = pygame.sprite.groupcollide(
            self.bullets, self.aliens, True, True)
        
        if collisions:
            for aliens in collisions.values():
              self.stats.score += self.settings.alien_points * len(aliens)

            
            self.score_board.prep_score()
            self.score_board.check_high_score()
            
          
        if not self.aliens:
                self.bullets.empty()
                self._create_fleet()
                self.settings.increase_speed()


                # Increase level
                self.stats.level += 1 
                self.score_board.prep_level()

        

        


    def _update_screen(self):
        """Update the screen and redraw the ship and bullets."""
        self.screen.fill(self.settings.bg_color)  # Fill the screen with the background color
        
        for bullet in self.bullets.sprites():
            bullet.draw_bullet()  # Draw all bullets on the screen

        self.ship.blitme()  # Draw the ship on the screen

        self.aliens.draw(self.screen)

        if not self.game_active:
            self.play_button.draw_button()
        
        self.score_board.show_score()

        

        

        pygame.display.flip()  # Update the display to show the new screen contents

        

    def run_game(self):
        """Start the main game loop."""
        while True:
            self._check_event() # Watch for keyboard and mouse events

            if self.game_active:

              self.ship.update()  # Update the ship's position based on key presses
              self._update_bullets()  # Update and remove bullets
              self._update_aliens()

            self._update_screen()  # Redraw the screen during each pass through the loop
            self.clock.tick(60)  # Limit the game to 60 frames per second (FPS)

if __name__ == "__main__":
    ai = AlienInvasion()  # Create an instance of the game
    ai.run_game()  # Start the game loop
