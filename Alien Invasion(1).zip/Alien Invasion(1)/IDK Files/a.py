import sys
import pygame
from pygame.sprite import Sprite

class Settings:
    """Class to store all settings for the game."""
    def __init__(self):
        # Screen settings
        self.screen_width = 1200  # Width of the game window
        self.screen_height = 500  # Height of the game window
        self.bg_color = (230, 230, 230)  # Background color (light gray)
        self.bullet_speed = 2.0
        self.bullet_width = 3 
        self.bullet_height = 15 
        self.bullet_color = (60, 60, 60)
        
        # Ship settings
        self.ship_speed = 10.5  # Speed at which the ship moves


class Ship:
    """Class to manage the ship."""
    def __init__(self, ai_game):
        """Initialize the ship and set its starting position"""
        self.screen = ai_game.screen  # Screen where the ship will be displayed
        self.screen_rect = ai_game.screen.get_rect()  # Rectangular area of the screen
        
        # Load the ship's image and get its rectangle
        self.image = pygame.image.load("images/ship.bmp")  # Load the ship image
        self.rect = self.image.get_rect()  # Get the rectangle of the ship image
        self.rect.midbottom = self.screen_rect.midbottom  # Position the ship at the bottom center of the screen
        
        # Flags to track movement
        self.moving_right = False  # Ship is not moving right initially
        self.moving_left = False   # Ship is not moving left initially
        
        # Access to settings for speed
        self.settings = ai_game.settings
        
        # Store a decimal value for the ship's horizontal position for smoother movement
        self.x = float(self.rect.x)

    def update(self):
        """Update the ship's position based on movement flags."""
        if self.moving_right and self.rect.right < self.screen_rect.right:
            self.x += self.settings.ship_speed  # Move the ship right, respecting the screen's right edge

        if self.moving_left and self.rect.left > 0:
            self.x -= self.settings.ship_speed  # Move the ship left, respecting the screen's left edge

        self.rect.x = self.x  # Apply the updated x position to the ship's rect

    def blitme(self):
        """Draw the ship at its current position."""
        self.screen.blit(self.image, self.rect)  # Blit (draw) the ship onto the screen at its rect position


class Bullet(Sprite):
    """Class to manage bullets fired from the ship."""
    def __init__(self, ai_game):
        super().__init__()
        self.screen = ai_game.screen 
        self.settings = ai_game.settings
        self.color = self.settings.bullet_color

        # Create the rectangle for bullets
        self.rect = pygame.Rect(0, 0, self.settings.bullet_width, self.settings.bullet_height)
        self.rect.midtop = ai_game.ship.rect.midtop 

        self.y = float(self.rect.y)

    def update(self):
        """Move the bullet up the screen."""
        self.y -= self.settings.bullet_speed 
        self.rect.y = self.y

    def draw_bullet(self):
        """Draw the bullet to the screen."""
        pygame.draw.rect(self.screen, self.color, self.rect)


class AlienInvasion:
    """Overall class to manage game assets and behavior."""
    def __init__(self):
        """Initialize the game and create game resources."""
        pygame.init()  # Initialize pygame
        self.settings = Settings()  # Create an instance of the Settings class
        self.screen = pygame.display.set_mode((self.settings.screen_width, self.settings.screen_height))  # Set up the screen
        pygame.display.set_caption("Alien Invasion")  # Set the title of the game window
        self.clock = pygame.time.Clock()  # Create a clock object to control the frame rate
        self.ship = Ship(self)  # Create a ship object, passing the current game instance
        self.bullets = pygame.sprite.Group()

    def _check_event(self):
        """Check for keyboard and mouse events."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()  # Exit the game if the close button is clicked
            
            elif event.type == pygame.KEYDOWN:
                self._check_KEYDOWN_events(event)
                  # Start moving the ship to the left

            elif event.type == pygame.KEYUP:
                self._check_KEYUP_events(event)  # Stop moving the ship to the left
                
    def _check_KEYDOWN_events(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RIGHT:
                self.ship.moving_right = True  # Start moving the ship to the right
            elif event.key == pygame.K_LEFT:
                self.ship.moving_left = True
            elif event.key == pygame.K_q:
                sys.exit()
            elif event.key == pygame.K_SPACE:
                self._fire_bullet() 
    
    def _check_KEYUP_events(self, event):
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_RIGHT:
                self.ship.moving_right = False 
            elif event.key == pygame.K_LEFT:
                self.ship.moving_left = False
    
    def _fire_bullet(self):
        """Create a new bullet and add it to the bullets group."""
        new_bullet = Bullet(self)
        self.bullets.add(new_bullet)

    def _update_screen(self):
        """Update the screen and redraw the ship."""
        self.screen.fill(self.settings.bg_color)  # Fill the screen with the background color
        for bullet in self.bullets.sprites():
            bullet.draw_bullet()
        self.ship.blitme()  # Draw the ship at its current position

        pygame.display.flip()  # Make the updated screen visible

    def run_game(self):
        """Start the main game loop."""
        while True:
            self._check_event()  # Watch for keyboard and mouse events

            self.ship.update()  # Update the ship's position based on key presses

            self.bullets.update()

            self._update_screen()  # Redraw the screen during each pass through the loop
            
            self.clock.tick(60)  # Limit the game to 60 frames per second (FPS)


if __name__ == "__main__":
    ai = AlienInvasion()  # Create an instance of the game
    ai.run_game()  # Run the game
